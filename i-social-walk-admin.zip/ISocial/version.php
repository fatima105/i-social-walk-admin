<?php echo phpinfo();
