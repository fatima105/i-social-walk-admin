<?php
include('../include/connection.php');
date_default_timezone_set("Asia/Karachi");
echo date('Y-d-m H:i:s');
