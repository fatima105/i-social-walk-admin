<?php

$data = json_decode(file_get_contents("php://input"), true);

header('Content-Type: application/json');
$name = $data['name'];
$this_user_id = $data['this_user_id'];
include('../include/connection.php');
$sql = "Select * from friend_list WHERE  this_user_id='$this_user_id' AND status='approved'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $sql_f = "SELECT * FROM users WHERE first_name LIKE '%$name%' OR last_name LIKE '%$name%'";
        $result_f = mysqli_query($conn, $sql_f);
        while ($row_f = mysqli_fetch_assoc($result_f)) {
            if ($row['friend_user_id'] == $row_f['id']) {
                $response[] = array(
                    "f_id" => $row_f['id'],
                    "first_name" => $row_f['first_name'],
                    "last_name" => $row_f['last_name'],

                );
                break;
            }
        }
    }


    $res = array(
        "data" => $response,
        "error" => false,
        "message" => 'Succesfully fetched friend',
    );
} else {
    $res = array(

        "error" => false,
        "message" => 'empty friend list',
    );
}

// }
echo json_encode($res);
