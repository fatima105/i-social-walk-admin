<?php
include('../include/functions.php');
include('../include/connection.php');
$EncodeData = file_get_contents('php://input');
$DecodeData = json_decode($EncodeData, true);
$reported_by = $DecodeData['reported_by'];

$sql = "Select * from report_challenge where reported_by='$reported_by' ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = array(
            'Reported challenge' => $row['report_challenge'],
            'Reported User' => $row['reported_by'],
            "comments" => $row['comments'],
            "created Date" => $row['created_date'],
        );
    }
} else {
    $response[] = array('message' => ' you havent reported anybody ', 'error' => 'true');
}
echo json_encode($response);
